#include <iostream>
#include <climits>
using namespace std;

int main()
{   int n;
   cin>>n;
   int number;
    int max_so_far=INT_MIN;
    int min_so_far=INT_MAX;
    
    for(int x=1;x<=n;x++)
{     cin>>number;
    if(max_so_far<number)
    {
        max_so_far=number;
    }    
    if(min_so_far>number)
    {
        min_so_far=number;
    }
}
    cout<<"MAX :"<<max_so_far<<endl;
    cout<<"MIN :"<<min_so_far<<endl;

    return 0;
}